# ShoppingCartAndroid
A simple and easy shopping cart implementation without using any database in android,
only some lines of code implemented for adding all functionality of shopping cart.
so enjoy your shopping cart!
thank you!

![Screenshot_2019-05-22-20-32-58-55](https://user-images.githubusercontent.com/45765123/58186338-4f7bca80-7cd2-11e9-8979-e5a7d27ba54b.png)
![Screenshot_2019-05-22-20-33-09-57](https://user-images.githubusercontent.com/45765123/58186385-67534e80-7cd2-11e9-82cb-beab6a175c58.png)
![Screenshot_2019-05-22-20-33-33-75](https://user-images.githubusercontent.com/45765123/58186442-84881d00-7cd2-11e9-8457-9f9c55c0e0b8.png)
![Screenshot_2019-05-22-20-33-40-80](https://user-images.githubusercontent.com/45765123/58186469-92d63900-7cd2-11e9-8c3d-634c5fe2d371.png)
